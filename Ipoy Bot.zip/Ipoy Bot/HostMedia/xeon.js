{
	"name": "Fuirly Bot Multi Device "
}